// Manager-specific JavaScript functionality
class ManagerDashboard {
    constructor() {
        this.currentUser = null;
        this.init();
    }

    init() {
        this.loadCurrentUser();
        this.setupEventListeners();
    }

    loadCurrentUser() {
        const userData = localStorage.getItem('currentUser');
        if (userData) {
            this.currentUser = JSON.parse(userData);
        }
    }

    setupEventListeners() {
        // Filter functionality
        this.setupFilters();
        
        // Approval actions
        this.setupApprovalActions();
    }

    setupFilters() {
        const statusFilter = document.getElementById('statusFilter');
        const typeFilter = document.getElementById('leaveTypeFilter');

        if (statusFilter) {
            statusFilter.addEventListener('change', this.filterLeaveRequests.bind(this));
        }

        if (typeFilter) {
            typeFilter.addEventListener('change', this.filterLeaveRequests.bind(this));
        }
    }

    setupApprovalActions() {
        // Event delegation for dynamically created buttons
        document.addEventListener('click', (event) => {
            if (event.target.classList.contains('approve-btn')) {
                const leaveId = parseInt(event.target.dataset.leaveId);
                this.approveLeave(leaveId);
            } else if (event.target.classList.contains('reject-btn')) {
                const leaveId = parseInt(event.target.dataset.leaveId);
                this.rejectLeave(leaveId);
            }
        });
    }

    getAllLeaveRequests() {
        const leaves = JSON.parse(localStorage.getItem('leaves')) || [];
        return leaves.sort((a, b) => new Date(b.appliedDate) - new Date(a.appliedDate));
    }

    filterLeaveRequests() {
        const statusFilter = document.getElementById('statusFilter');
        const typeFilter = document.getElementById('leaveTypeFilter');
        
        if (!statusFilter || !typeFilter) return;

        const statusValue = statusFilter.value;
        const typeValue = typeFilter.value;
        
        let leaves = this.getAllLeaveRequests();

        // Apply status filter
        if (statusValue !== 'all') {
            leaves = leaves.filter(leave => leave.status === statusValue);
        }

        // Apply type filter
        if (typeValue !== 'all') {
            leaves = leaves.filter(leave => leave.leaveType === typeValue);
        }

        this.displayLeaveRequests(leaves);
    }

    displayLeaveRequests(leaves) {
        const tbody = document.getElementById('approvalTableBody');
        if (!tbody) return;

        tbody.innerHTML = '';

        if (leaves.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="no-data">No leave requests found</td></tr>';
            return;
        }

        leaves.forEach(leave => {
            const row = this.createLeaveRequestRow(leave);
            tbody.appendChild(row);
        });
    }

    createLeaveRequestRow(leave) {
        const row = document.createElement('tr');
        
        // Calculate days
        const days = this.calculateDays(leave.fromDate, leave.toDate);
        
        row.innerHTML = `
            <td>${leave.employeeName}</td>
            <td>${leave.department || 'N/A'}</td>
            <td>${leave.leaveType}</td>
            <td>${this.formatDate(leave.fromDate)}</td>
            <td>${this.formatDate(leave.toDate)}</td>
            <td>${days}</td>
            <td>${this.formatDate(leave.appliedDate)}</td>
            <td><span class="status ${leave.status.toLowerCase()}">${leave.status}</span></td>
            <td class="actions">
                <button class="btn-small btn-info" onclick="viewLeaveDetails(${leave.id})">View</button>
                ${leave.status === 'Pending' ? `
                    <button class="btn-small btn-success approve-btn" data-leave-id="${leave.id}">Approve</button>
                    <button class="btn-small btn-danger reject-btn" data-leave-id="${leave.id}">Reject</button>
                ` : ''}
            </td>
        `;

        return row;
    }

    approveLeave(leaveId) {
        if (confirm('Are you sure you want to approve this leave request?')) {
            this.updateLeaveStatus(leaveId, 'Approved');
        }
    }

    rejectLeave(leaveId) {
        if (confirm('Are you sure you want to reject this leave request?')) {
            this.updateLeaveStatus(leaveId, 'Rejected');
        }
    }

    updateLeaveStatus(leaveId, status) {
        try {
            const leaves = JSON.parse(localStorage.getItem('leaves')) || [];
            const leaveIndex = leaves.findIndex(leave => leave.id === leaveId);

            if (leaveIndex === -1) {
                this.showError('Leave request not found');
                return;
            }

            // Update leave status
            leaves[leaveIndex].status = status;
            leaves[leaveIndex].reviewedDate = new Date().toISOString().split('T')[0];
            leaves[leaveIndex].reviewedBy = this.currentUser.name;

            // Save updated leaves
            localStorage.setItem('leaves', JSON.stringify(leaves));

            // Show success notification
            const message = status === 'Approved' 
                ? 'Leave request approved successfully!' 
                : 'Leave request rejected successfully!';
            
            this.showNotification(message, status === 'Approved' ? 'success' : 'warning');

            // Refresh the display
            this.filterLeaveRequests();

            // Send notification to employee (in a real app, this would be an email/push notification)
            this.notifyEmployee(leaves[leaveIndex]);

        } catch (error) {
            console.error('Error updating leave status:', error);
            this.showError('Failed to update leave status. Please try again.');
        }
    }

    notifyEmployee(leave) {
        // In a real application, this would send an email or push notification
        // For demo purposes, we'll just log it
        console.log(`Notification sent to ${leave.employeeName}: Your ${leave.leaveType} leave request has been ${leave.status.toLowerCase()}.`);
        
        // Store notification in localStorage for demo
        const notifications = JSON.parse(localStorage.getItem('notifications')) || [];
        notifications.push({
            id: Date.now(),
            employeeId: leave.employeeId,
            message: `Your ${leave.leaveType} leave request from ${leave.fromDate} to ${leave.toDate} has been ${leave.status.toLowerCase()}.`,
            timestamp: new Date().toISOString(),
            read: false
        });
        localStorage.setItem('notifications', JSON.stringify(notifications));
    }

    getLeaveStatistics() {
        const leaves = this.getAllLeaveRequests();
        
        return {
            total: leaves.length,
            pending: leaves.filter(leave => leave.status === 'Pending').length,
            approved: leaves.filter(leave => leave.status === 'Approved').length,
            rejected: leaves.filter(leave => leave.status === 'Rejected').length
        };
    }

    getDepartmentStatistics() {
        const leaves = this.getAllLeaveRequests();
        const departments = {};

        leaves.forEach(leave => {
            const dept = leave.department || 'Unknown';
            if (!departments[dept]) {
                departments[dept] = {
                    total: 0,
                    pending: 0,
                    approved: 0,
                    rejected: 0
                };
            }
            departments[dept].total++;
            departments[dept][leave.status.toLowerCase()]++;
        });

        return departments;
    }

    getLeaveTypeStatistics() {
        const leaves = this.getAllLeaveRequests();
        const types = {};

        leaves.forEach(leave => {
            const type = leave.leaveType;
            if (!types[type]) {
                types[type] = {
                    total: 0,
                    pending: 0,
                    approved: 0,
                    rejected: 0
                };
            }
            types[type].total++;
            types[type][leave.status.toLowerCase()]++;
        });

        return types;
    }

    generateReport(type = 'summary') {
        const leaves = this.getAllLeaveRequests();
        const report = {
            generatedDate: new Date().toISOString(),
            generatedBy: this.currentUser.name,
            type: type,
            data: {}
        };

        switch (type) {
            case 'summary':
                report.data = this.getLeaveStatistics();
                break;
            case 'department':
                report.data = this.getDepartmentStatistics();
                break;
            case 'leaveType':
                report.data = this.getLeaveTypeStatistics();
                break;
            case 'detailed':
                report.data = leaves;
                break;
        }

        return report;
    }

    exportReport(format = 'json') {
        const report = this.generateReport('detailed');
        
        if (format === 'json') {
            const dataStr = JSON.stringify(report, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            this.downloadFile(dataBlob, 'leave_report.json');
        } else if (format === 'csv') {
            const csv = this.convertToCSV(report.data);
            const dataBlob = new Blob([csv], { type: 'text/csv' });
            this.downloadFile(dataBlob, 'leave_report.csv');
        }
    }

    convertToCSV(data) {
        if (!Array.isArray(data) || data.length === 0) return '';

        const headers = Object.keys(data[0]);
        const csvContent = [
            headers.join(','),
            ...data.map(row => 
                headers.map(header => 
                    JSON.stringify(row[header] || '')
                ).join(',')
            )
        ].join('\n');

        return csvContent;
    }

    downloadFile(blob, filename) {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
    }

    calculateDays(fromDate, toDate) {
        const from = new Date(fromDate);
        const to = new Date(toDate);
        const diffTime = Math.abs(to - from);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Show with animation
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    showSuccess(message) {
        this.showNotification(message, 'success');
    }
}

// Initialize manager dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize if user is a manager
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
        const userData = JSON.parse(currentUser);
        if (userData.role === 'manager' && typeof window.managerDashboard === 'undefined') {
            window.managerDashboard = new ManagerDashboard();
        }
    }
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ManagerDashboard;
}