// Employee-specific JavaScript functionality
class EmployeeManager {
    constructor() {
        this.currentUser = null;
        this.init();
    }

    init() {
        this.loadCurrentUser();
        this.setupEventListeners();
    }

    loadCurrentUser() {
        const userData = localStorage.getItem('currentUser');
        if (userData) {
            this.currentUser = JSON.parse(userData);
        }
    }

    setupEventListeners() {
        // Form validation for leave application
        const leaveForm = document.getElementById('leaveApplicationForm');
        if (leaveForm) {
            leaveForm.addEventListener('submit', this.handleLeaveSubmission.bind(this));
        }

        // Date validation
        this.setupDateValidation();
    }

    setupDateValidation() {
        const fromDate = document.getElementById('fromDate');
        const toDate = document.getElementById('toDate');

        if (fromDate && toDate) {
            fromDate.addEventListener('change', this.validateDates.bind(this));
            toDate.addEventListener('change', this.validateDates.bind(this));
        }
    }

    validateDates() {
        const fromDate = document.getElementById('fromDate');
        const toDate = document.getElementById('toDate');
        const totalDays = document.getElementById('totalDays');

        if (fromDate.value && toDate.value) {
            const from = new Date(fromDate.value);
            const to = new Date(toDate.value);
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            // Validate from date is not in the past
            if (from < today) {
                this.showValidationError('From date cannot be in the past');
                fromDate.value = '';
                return false;
            }

            // Validate to date is not before from date
            if (to < from) {
                this.showValidationError('To date must be after from date');
                toDate.value = '';
                return false;
            }

            // Calculate total days
            const diffTime = Math.abs(to - from);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
            
            if (totalDays) {
                totalDays.value = diffDays;
            }

            return true;
        }
        return false;
    }

    handleLeaveSubmission(event) {
        event.preventDefault();
        
        if (!this.currentUser) {
            this.showError('User not authenticated');
            return;
        }

        const formData = new FormData(event.target);
        const leaveData = this.extractLeaveData(formData);

        if (this.validateLeaveApplication(leaveData)) {
            this.submitLeaveApplication(leaveData);
        }
    }

    extractLeaveData(formData) {
        return {
            id: Date.now(),
            employeeId: this.currentUser.id,
            employeeName: this.currentUser.name,
            department: this.currentUser.department,
            leaveType: formData.get('leaveType'),
            fromDate: formData.get('fromDate'),
            toDate: formData.get('toDate'),
            reason: formData.get('reason'),
            contactNumber: formData.get('contactNumber') || '',
            totalDays: parseInt(formData.get('totalDays')) || 0,
            status: 'Pending',
            appliedDate: new Date().toISOString().split('T')[0]
        };
    }

    validateLeaveApplication(leaveData) {
        // Check required fields
        if (!leaveData.leaveType || !leaveData.fromDate || !leaveData.toDate || !leaveData.reason.trim()) {
            this.showError('Please fill in all required fields');
            return false;
        }

        // Validate dates
        const fromDate = new Date(leaveData.fromDate);
        const toDate = new Date(leaveData.toDate);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (fromDate < today) {
            this.showError('From date cannot be in the past');
            return false;
        }

        if (toDate < fromDate) {
            this.showError('To date must be after from date');
            return false;
        }

        // Check for overlapping leave requests
        if (this.hasOverlappingLeave(leaveData.fromDate, leaveData.toDate)) {
            this.showError('You already have a leave request for this period');
            return false;
        }

        return true;
    }

    hasOverlappingLeave(fromDate, toDate) {
        const leaves = JSON.parse(localStorage.getItem('leaves')) || [];
        const userLeaves = leaves.filter(leave => 
            leave.employeeId === this.currentUser.id && 
            leave.status !== 'Rejected'
        );

        const newFrom = new Date(fromDate);
        const newTo = new Date(toDate);

        return userLeaves.some(leave => {
            const existingFrom = new Date(leave.fromDate);
            const existingTo = new Date(leave.toDate);

            return (newFrom <= existingTo && newTo >= existingFrom);
        });
    }

    submitLeaveApplication(leaveData) {
        try {
            // Get existing leaves
            const leaves = JSON.parse(localStorage.getItem('leaves')) || [];
            
            // Add new leave
            leaves.push(leaveData);
            
            // Save to localStorage
            localStorage.setItem('leaves', JSON.stringify(leaves));
            
            // Show success message
            this.showSuccess('Leave application submitted successfully! You will be notified once it is reviewed.');
            
            // Reset form
            this.resetLeaveForm();
            
            // Update leave balance display
            this.updateLeaveBalance();
            
        } catch (error) {
            console.error('Error submitting leave application:', error);
            this.showError('Failed to submit leave application. Please try again.');
        }
    }

    resetLeaveForm() {
        const form = document.getElementById('leaveApplicationForm');
        if (form) {
            form.reset();
            const totalDays = document.getElementById('totalDays');
            if (totalDays) {
                totalDays.value = '';
            }
        }
    }

    updateLeaveBalance() {
        // This would typically connect to a backend to get real balance data
        // For now, we'll use static data
        const balanceData = {
            casual: 12,
            medical: 7,
            annual: 15
        };

        // Update balance display if elements exist
        const balanceElements = document.querySelectorAll('.balance-count');
        if (balanceElements.length > 0) {
            balanceElements[0].textContent = `${balanceData.casual} days`;
            balanceElements[1].textContent = `${balanceData.medical} days`;
            balanceElements[2].textContent = `${balanceData.annual} days`;
        }
    }

    getEmployeeLeaveHistory() {
        if (!this.currentUser) return [];
        
        const leaves = JSON.parse(localStorage.getItem('leaves')) || [];
        return leaves.filter(leave => leave.employeeId === this.currentUser.id)
                   .sort((a, b) => new Date(b.appliedDate) - new Date(a.appliedDate));
    }

    getLeaveStatistics() {
        const history = this.getEmployeeLeaveHistory();
        
        return {
            total: history.length,
            pending: history.filter(leave => leave.status === 'Pending').length,
            approved: history.filter(leave => leave.status === 'Approved').length,
            rejected: history.filter(leave => leave.status === 'Rejected').length
        };
    }

    showSuccess(message) {
        this.showMessage(message, 'success');
    }

    showError(message) {
        this.showMessage(message, 'error');
    }

    showValidationError(message) {
        this.showMessage(message, 'error');
    }

    showMessage(message, type) {
        const messageElement = document.getElementById(`${type}Message`);
        if (messageElement) {
            messageElement.textContent = message;
            messageElement.style.display = 'block';
            
            // Hide other message types
            const otherType = type === 'success' ? 'error' : 'success';
            const otherElement = document.getElementById(`${otherType}Message`);
            if (otherElement) {
                otherElement.style.display = 'none';
            }
            
            // Auto-hide success messages after 5 seconds
            if (type === 'success') {
                setTimeout(() => {
                    messageElement.style.display = 'none';
                }, 5000);
            }
        } else {
            // Fallback to alert if elements don't exist
            alert(message);
        }
    }

    // Utility method to format date
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    // Utility method to calculate days between dates
    calculateDaysBetween(fromDate, toDate) {
        const from = new Date(fromDate);
        const to = new Date(toDate);
        const diffTime = Math.abs(to - from);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    }
}

// Initialize employee manager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    if (typeof window.employeeManager === 'undefined') {
        window.employeeManager = new EmployeeManager();
    }
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EmployeeManager;
}