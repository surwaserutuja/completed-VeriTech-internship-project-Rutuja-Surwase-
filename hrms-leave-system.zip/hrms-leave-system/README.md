# HRMS Leave Management System

A comprehensive web-based Leave Management System built with HTML, CSS, and JavaScript that allows employees to apply for leaves and managers to review and approve/reject them.

## 🚀 Features

### Employee Features
- **User Authentication**: Secure login with role-based access
- **Leave Application**: Apply for different types of leaves with form validation
- **Leave History**: View personal leave history and status
- **Dashboard**: Overview of leave statistics and recent requests
- **Real-time Validation**: Form validation with date checks and overlap detection

### Manager Features
- **Approval Interface**: Review and approve/reject leave requests
- **Filter Options**: Filter leaves by status and type
- **Detailed View**: View complete leave request details
- **Dashboard Analytics**: Statistics and overview of all leave requests
- **Notification System**: Automated notifications for status updates

### General Features
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices
- **Modern UI**: Clean and professional interface design
- **Local Storage**: Data persistence using browser local storage
- **Demo Data**: Pre-loaded with sample users and leave requests

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Storage**: Browser Local Storage
- **Design**: Responsive CSS Grid and Flexbox
- **Icons**: Unicode emoji icons for simplicity

## 📁 Project Structure

```
hrms-leave-system/
├── index.html          # Dashboard page
├── login.html          # Login page
├── applyLeave.html     # Leave application form
├── approval.html       # Manager approval page
├── style.css          # Main stylesheet
├── employee.js        # Employee-specific functionality
├── manager.js         # Manager-specific functionality
└── README.md          # Project documentation
```

## 🚦 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- No additional software or dependencies required

### Installation
1. **Clone or Download** the project files
2. **Open** `login.html` in your web browser
3. **Use demo credentials** to login (see below)

### Demo Credentials

#### Employee Access
- **Email**: john.doe@company.com
- **Password**: employee123
- **Role**: Employee

#### Manager Access
- **Email**: sarah.manager@company.com
- **Password**: manager123
- **Role**: Manager

## 📱 Usage Guide

### For Employees

1. **Login** using employee credentials
2. **Dashboard**: View your leave statistics and recent requests
3. **Apply Leave**: 
   - Navigate to "Apply Leave"
   - Fill out the form with leave details
   - Submit for manager approval
4. **Leave History**: View all your past and current leave requests

### For Managers

1. **Login** using manager credentials
2. **Dashboard**: Overview of all leave requests and statistics
3. **Approvals**:
   - Navigate to "Approvals"
   - Filter requests by status or type
   - Review details and approve/reject requests
4. **Notifications**: Automatic notifications sent to employees

## 🎨 Design Features

### Visual Design
- **Clean Interface**: Modern and professional appearance
- **Color Scheme**: Blue sidebar with light gray content area
- **Typography**: Readable fonts with proper hierarchy
- **Status Indicators**: Color-coded status badges

### User Experience
- **Intuitive Navigation**: Clear sidebar navigation
- **Form Validation**: Real-time validation with helpful error messages
- **Responsive Layout**: Adapts to different screen sizes
- **Modal Dialogs**: Detailed view popups for leave requests

### Responsive Design
- **Mobile-First**: Optimized for mobile devices
- **Breakpoints**: 
  - Mobile: < 768px
  - Tablet: 768px - 1024px
  - Desktop: > 1024px

## 🔧 Key Functionalities

### Form Validation
- Required field validation
- Date range validation
- Past date prevention
- Overlapping leave detection

### Data Management
- Local storage for data persistence
- JSON data structure
- CRUD operations for leave requests
- User session management

### Status Management
- Pending → Approved/Rejected workflow
- Status tracking and history
- Notification system

## 📊 Project Phases

### Phase 1: UI Design & Structure ✅
- Created all HTML pages
- Implemented responsive CSS design
- Built navigation and layout structure

### Phase 2: Employee Functionality ✅
- Form validation and submission
- Local storage integration
- Leave history display
- Dashboard statistics

### Phase 3: Manager Functionality ✅
- Approval interface
- Filtering and sorting
- Status update logic
- Notification system

### Phase 4: Final Touches ✅
- Mobile responsiveness
- Error handling
- Documentation
- Demo data setup

## 🔒 Security Considerations

- **Client-Side Only**: This is a demo application using local storage
- **Production Use**: Would require:
  - Server-side authentication
  - Database integration
  - API security measures
  - Input sanitization

## 🚀 Future Enhancements

### Potential Improvements
- **Backend Integration**: RESTful API with database
- **Email Notifications**: Real email system
- **Calendar Integration**: Visual calendar view
- **Reporting**: Advanced analytics and reports
- **Multi-level Approval**: Complex approval workflows
- **Leave Balance**: Real-time balance calculation
- **Document Uploads**: Attach supporting documents

### Technical Enhancements
- **PWA Support**: Progressive Web App features
- **Offline Mode**: Offline functionality
- **Push Notifications**: Browser push notifications
- **Export Features**: PDF/Excel export functionality

## 🐛 Known Limitations

- Data stored in browser local storage (not persistent across devices)
- No real-time notifications (simulated)
- No email integration
- Client-side only (no server-side validation)
- Limited to single browser/device

## 🤝 Contributing

This is an educational project. For improvements:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is created for educational purposes. Feel free to use and modify as needed.

## 👥 Credits

**Developer**: Intern Project
**Duration**: May 15, 2025 - June 15, 2025
**Technology**: HTML, CSS, JavaScript

## 📞 Support

For questions or issues:
- Review the code comments
- Check browser console for errors
- Ensure local storage is enabled
- Verify demo credentials are used correctly

---

**Note**: This is a demonstration project built for learning purposes. For production use, proper backend integration, security measures, and database management would be required.